# ShelfSense AI - Autonomous Retail Compliance Agent

Streamlit app that audits shelf images/videos for planogram compliance, label/price accuracy and
availability, then ranks fixes by **revenue at risk (₹/day)**.

## Quick start
```bash
pip install -r requirements.txt
python data/generate_samples.py        # creates demo shelves with intentional errors
streamlit run app.py                   # works immediately in Demo mode (no GPU / model)
```

### Live vision-SLM mode
```bash
ollama pull qwen2.5vl:7b               # 7B < 20B -> SLM bonus. Use qwen2.5vl:3b for edge.
```
Choose **Live (Ollama VLM)** in the sidebar. If Ollama is unreachable the app falls back to demo mode and says so.

### Edge simulation
Toggle **Edge Simulation Mode** (image down-scaling, CPU-thread cap, latency budget) to see latency, FPS,
memory and quantised model size. For a hard resource cap:
`docker run --cpus=2 --memory=2g -p 8501:8501 shelfsense`

## Layout
| Path | Role |
|---|---|
| `app.py` | Dashboard: Upload -> Visual Audit -> Action Report -> Assumptions |
| `shelfsense/detector.py` | Qwen2.5-VL via Ollama + demo/simulated fallback |
| `shelfsense/ocr_pricing.py` | Price parsing, optional EasyOCR, catalogue comparison |
| `shelfsense/planogram.py` | SKU matching, compliance score, missing/misplaced detection |
| `shelfsense/recommender.py` | Fix instructions + revenue-at-risk ranking |
| `shelfsense/edge.py`, `visualize.py`, `pipeline.py` | Edge metrics, overlay, orchestration |

## Tests
`python tests/test_pipeline.py` (or `pytest tests -q`)

## Key assumptions
See the **Assumptions** tab in the app (golden-zone 1.5x weight, loss factors, grid mapping, price tolerance).
