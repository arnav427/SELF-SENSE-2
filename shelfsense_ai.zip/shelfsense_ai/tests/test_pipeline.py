"""Run with:  python -m pytest tests -q   (or just: python tests/test_pipeline.py)"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import Image

from shelfsense import config
from shelfsense.detector import DetectorSettings
from shelfsense.ocr_pricing import parse_price
from shelfsense.pipeline import run_audit
from shelfsense.planogram import load_catalog, load_planogram

CAT, PG = load_catalog(config.CATALOG_PATH), load_planogram(config.PLANOGRAM_PATH)


def audit(name):
    img = Image.open(config.SAMPLES_DIR / f"{name}.png")
    return run_audit(img, f"{name}.png", DetectorSettings(mode="demo"), CAT, PG)


def test_parse_price():
    assert parse_price("Rs 45") == 45
    assert parse_price("₹ 275.00") == 275
    assert parse_price("Rs ??") is None
    assert parse_price("") is None


def test_mixed_errors():
    r = audit("shelf_01_mixed_errors")
    c = r["evaluation"]["counts"]
    assert c["EMPTY"] == 1 and c["MISPLACED"] == 4 and c["LOW"] == 1
    types = {a["type"] for a in r["actions"]}
    assert {"STOCK_OUT", "SWAP", "LOW_STOCK", "PRICE_MISMATCH_OVERPRICED", "PRICE_MISMATCH_UNDERPRICED"} <= types
    assert r["evaluation"]["score"] < 80
    assert r["actions"][0]["revenue_at_risk"] >= r["actions"][-1]["revenue_at_risk"]


def test_clean_shelf_scores_high():
    r = audit("shelf_02_nearly_clean")
    assert r["evaluation"]["score"] == 100.0 and r["price_issues"] == []


def test_stockouts_and_label_flags():
    r = audit("shelf_03_stockouts_and_labels")
    types = {p["type"] for p in r["price_issues"]}
    assert {"MISSING_LABEL", "PRICE_UNREADABLE", "LABEL_PRODUCT_MISMATCH"} <= types


def test_live_mode_falls_back_when_ollama_down():
    img = Image.open(config.SAMPLES_DIR / "shelf_01_mixed_errors.png")
    cfg = DetectorSettings(mode="live", host="http://localhost:1")
    r = run_audit(img, "shelf_01_mixed_errors.png", cfg, CAT, PG)
    assert "Fell back" in r["detection"]["note"]


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
            print("PASS", k)
