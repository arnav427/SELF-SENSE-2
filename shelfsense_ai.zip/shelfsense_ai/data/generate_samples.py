"""Generates demo shelf images (with intentional errors) plus recorded-detection sidecar JSON files.

Run:  python data/generate_samples.py
"""
import json
import textwrap
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
OUT = HERE / "sample_shelves"
CELL_W, CELL_H = 220, 190
COLORS = {"Snacks": (234, 179, 8), "Beverages": (59, 130, 246), "Biscuits": (180, 110, 60), "Staples": (34, 160, 110)}


def font(size):
    for name in ("DejaVuSans.ttf", "Arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def base_state(catalog, planogram):
    cat = catalog.set_index("SKU_ID")
    state = {}
    for p in planogram["slots"]:
        r = cat.loc[p["sku"]]
        state[(p["row"], p["slot"])] = {"product": r["Name"], "stock": "full",
                                        "price_tag": f"Rs {r['Expected_Price']:g}", "label_product": r["Name"]}
    return state


def empty(s):
    s.update(product="EMPTY", stock="empty")


def swap(st, a, b):
    st[a]["product"], st[b]["product"] = st[b]["product"], st[a]["product"]


def scenario_mixed(st):
    empty(st[(1, 3)])                       # Bingo stock-out
    swap(st, (2, 2), (2, 4))                # Sprite <-> Thums Up at eye level
    st[(2, 1)]["price_tag"] = "Rs 45"       # Pepsi overpriced
    st[(3, 2)]["price_tag"] = "Rs 25"       # Good Day underpriced
    swap(st, (3, 1), (4, 2))                # Parle-G <-> Tata Salt
    st[(4, 1)]["stock"] = "low"             # Maggi low


def scenario_clean(st):
    st[(3, 4)]["stock"] = "low"


def scenario_stockouts(st):
    empty(st[(2, 1)])
    empty(st[(2, 3)])
    st[(2, 5)]["stock"] = "low"
    st[(1, 5)]["price_tag"] = ""            # missing label (Act II)
    st[(3, 3)]["price_tag"] = "Rs ??"       # unreadable label (Oreo)
    st[(4, 4)]["label_product"] = "Tata Tea Gold 250g"   # wrong label on Fortune Oil
    st[(3, 5)]["price_tag"] = "Rs 35"       # Marie Gold overpriced


def draw(state, path, rows=4, cols=5):
    W, H = cols * CELL_W, rows * CELL_H
    img = Image.new("RGB", (W, H), (226, 226, 230))
    d = ImageDraw.Draw(img)
    f_name, f_tag = font(14), font(16)
    cat_of = {}
    for (r, c), s in state.items():
        x0, y0 = (c - 1) * CELL_W, (r - 1) * CELL_H
        d.rectangle([x0, y0, x0 + CELL_W, y0 + CELL_H], outline=(140, 140, 150), width=2)
        d.rectangle([x0, y0 + CELL_H - 12 - 28, x0 + CELL_W, y0 + CELL_H - 12], fill=(250, 250, 250))  # tag strip
        d.text((x0 + 10, y0 + CELL_H - 36), f"{s['label_product'][:16]}  {s['price_tag']}".strip(), fill=(0, 0, 0), font=f_tag)
        d.rectangle([x0, y0 + CELL_H - 12, x0 + CELL_W, y0 + CELL_H], fill=(120, 120, 130))            # shelf edge
        if s["stock"] == "empty":
            d.text((x0 + 60, y0 + 60), "(empty)", fill=(150, 150, 150), font=f_name)
            continue
        cat = CATALOG_CAT.get(s["product"], "Snacks")
        facings = 3 if s["stock"] == "full" else 1
        bw = (CELL_W - 20) // 3
        for i in range(facings):
            bx = x0 + 10 + i * bw
            d.rectangle([bx, y0 + 20, bx + bw - 6, y0 + 20 + 110], fill=COLORS[cat], outline=(30, 30, 30), width=2)
            for j, line in enumerate(textwrap.wrap(s["product"], 9)[:5]):
                d.text((bx + 4, y0 + 26 + j * 16), line, fill=(255, 255, 255), font=font(11))
    img.save(path)


if __name__ == "__main__":
    catalog = pd.read_csv(HERE / "product_catalog.csv")
    planogram = json.load(open(HERE / "expected_planogram.json"))
    CATALOG_CAT = dict(zip(catalog["Name"], catalog["Category"]))
    OUT.mkdir(exist_ok=True)
    for name, fn in [("shelf_01_mixed_errors", scenario_mixed), ("shelf_02_nearly_clean", scenario_clean),
                     ("shelf_03_stockouts_and_labels", scenario_stockouts)]:
        st = base_state(catalog, planogram)
        fn(st)
        draw(st, OUT / f"{name}.png")
        slots = [{"row": r, "slot": c, **v} for (r, c), v in sorted(st.items())]
        json.dump({"slots": slots}, open(OUT / f"{name}.json", "w"), indent=1)
        print("wrote", name)
